const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');
const { pathToFileURL } = require('url');
const { EDGE_NOT_AVAILABLE, launchEdgeBrowser } = require('../src/shared/edge-browser');

const { renderSnapshot } = require('../src/adapters/html');
const { reverseSnapshotToSemanticModel } = require('../src/adapters/indesign');
const hostJsx = require('../src/indesign-cli-plugin/host-jsx');
const { compileDocument } = require('../src/indesign-pipeline');
const { auditForwardFidelity } = require('../src/semantic-model');
const { validateInstructions } = require('../src/writers/indesign');
const { readAuthorPackage } = require('../src/authoring');
const { resolveSemanticPreset, presetToStyleNameMap } = require('../src/semantic-preset');
const {
  resolveReconstructionProfile,
  assertResolvedReconstructionProfile,
  RECONSTRUCTION_PROFILE_NAMES,
} = require('../src/semantic-reconstruction');
const {
  assertPanelNameAuditOk,
  observedPanelNamesForHtml,
  assertNoLossyVectorWarnings,
  assertNoTextOverset,
} = require('../src/writers/indesign/audit/e2e-result-audit');
const {
  auditReverseHtmlSemantics,
  assertReverseHtmlSemantics,
  auditSecondPassAuthorStability,
} = require('../src/writers/html/audit/reverse-roundtrip');

function createRunContext(options = {}) {
  const repoRoot = path.resolve(options.repoRoot || path.join(__dirname, '..'));
  const workspaceDir = path.resolve(options.workspaceDir || path.join(repoRoot, 'test/workspace'));
  const timestamp = options.timestamp || timestampFor(new Date());
  const runDir = path.resolve(options.runDir || path.join(workspaceDir, `indesign-e2e-${timestamp}`));
  const htmlPath = path.resolve(options.htmlPath || path.join(repoRoot, 'test/fixtures/e2e/architecture-report/deck.html'));
  return {
    repoRoot,
    workspaceDir,
    runDir,
    htmlPath,
    timestamp,
    defaultInstructionsPath: path.join(workspaceDir, 'instructions.json'),
    runInstructionsPath: path.join(runDir, 'instructions.json'),
    expectedModelPath: path.join(runDir, 'expected-semantic-model.json'),
    semanticPresetPath: path.join(runDir, 'expected-semantic-preset.json'),
    fidelityReportPath: path.join(runDir, 'forward-fidelity-report.json'),
    compileSummaryPath: path.join(runDir, 'compile-summary.json'),
    resultPath: path.join(runDir, 'e2e-result.json'),
    buildScriptPath: path.join(runDir, 'build-latest.jsx'),
    exportScriptPath: path.join(runDir, 'export-latest.jsx'),
    reverseScriptPath: path.join(runDir, 'reverse-snapshot.jsx'),
    reverseSnapshotPath: path.join(runDir, 'reverse-snapshot.json'),
    reverseOutDir: path.join(runDir, 'reverse-html'),
    previewDir: path.join(runDir, 'preview'),
  };
}

function createHumanInddRunContext(options = {}) {
  if (!options.inddPath) {
    throw new Error('createHumanInddRunContext requires inddPath');
  }
  const repoRoot = path.resolve(options.repoRoot || path.join(__dirname, '..'));
  const workspaceDir = path.resolve(options.workspaceDir || path.join(repoRoot, 'test/workspace'));
  const timestamp = options.timestamp || timestampFor(new Date());
  const runDir = path.resolve(options.runDir || path.join(workspaceDir, `human-indd-e2e-${timestamp}`));
  const inddPath = path.resolve(options.inddPath);
  return {
    repoRoot,
    workspaceDir,
    runDir,
    inddPath,
    timestamp,
    reverseScriptPath: path.join(runDir, 'reverse-snapshot.jsx'),
    reverseSnapshotPath: path.join(runDir, 'reverse-snapshot.json'),
    reverseOutDir: path.join(runDir, 'reverse-html'),
    authorRoundtripDir: path.join(runDir, 'generated-author-e2e'),
    resultPath: path.join(runDir, 'human-indd-e2e-result.json'),
  };
}

function timestampFor(date) {
  const pad = (value) => String(value).padStart(2, '0');
  return [
    date.getFullYear(),
    pad(date.getMonth() + 1),
    pad(date.getDate()),
    '-',
    pad(date.getHours()),
    pad(date.getMinutes()),
    pad(date.getSeconds()),
  ].join('');
}

function parseArgs(argv, repoRoot) {
  const options = { repoRoot, reconstructAlgorithms: [] };
  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === '--html') {
      options.htmlPath = argv[++index];
    } else if (arg.startsWith('--html=')) {
      options.htmlPath = arg.slice('--html='.length);
    } else if (arg === '--indd') {
      options.inddPath = argv[++index];
    } else if (arg.startsWith('--indd=')) {
      options.inddPath = arg.slice('--indd='.length);
    } else if (arg === '--run-dir') {
      options.runDir = argv[++index];
    } else if (arg.startsWith('--run-dir=')) {
      options.runDir = arg.slice('--run-dir='.length);
    } else if (arg === '--timestamp') {
      options.timestamp = argv[++index];
    } else if (arg.startsWith('--timestamp=')) {
      options.timestamp = arg.slice('--timestamp='.length);
    } else if (arg === '--target-size') {
      options.targetSize = argv[++index];
    } else if (arg.startsWith('--target-size=')) {
      options.targetSize = arg.slice('--target-size='.length);
    } else if (arg === '--unit-mode') {
      options.unitMode = argv[++index];
    } else if (arg.startsWith('--unit-mode=')) {
      options.unitMode = arg.slice('--unit-mode='.length);
    } else if (arg === '--skip-preview') {
      options.skipPreview = true;
    } else if (arg === '--reverse-roundtrip') {
      options.reverseRoundtrip = true;
    } else if (arg === '--reverse-mode') {
      options.reverseMode = parseReverseMode(argv[++index]);
    } else if (arg.startsWith('--reverse-mode=')) {
      options.reverseMode = parseReverseMode(arg.slice('--reverse-mode='.length));
    } else if (arg === '--reconstruction-profile') {
      options.reconstructionProfileName = argv[++index];
    } else if (arg.startsWith('--reconstruction-profile=')) {
      options.reconstructionProfileName = arg.slice('--reconstruction-profile='.length);
    } else if (arg === '--reconstruct') {
      options.reconstructAlgorithms = parseAlgorithmList(argv[++index]);
    } else if (arg.startsWith('--reconstruct=')) {
      options.reconstructAlgorithms = parseAlgorithmList(arg.slice('--reconstruct='.length));
    } else if (arg === '--second-pass-roundtrip') {
      options.secondPassRoundtrip = true;
    } else if (arg === '--help' || arg === '-h') {
      options.help = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  if (options.inddPath) {
    options.reverseRoundtrip = true;
    options.secondPassRoundtrip = true;
    if (!options.reverseMode) options.reverseMode = 'observation';
  }
  options.reconstructionProfile = resolveReconstructionProfile({
    profile: options.reconstructionProfileName,
    algorithms: options.reconstructAlgorithms,
  });
  delete options.reconstructionProfileName;
  delete options.reconstructAlgorithms;
  return options;
}

function usage() {
  return [
    `Usage: node scripts/indesign-e2e.js [--html <deck.html> | --indd <document.indd>] [--target-size qhd|2560x1440|same] [--run-dir <dir>] [--skip-preview] [--reverse-roundtrip] [--reverse-mode structured|inferred|observation] [--second-pass-roundtrip] [--reconstruction-profile ${RECONSTRUCTION_PROFILE_NAMES.join('|')}] [--reconstruct <algorithms>]`,
    'npm: npm run e2e:indesign -- -- --target-size qhd --reverse-roundtrip --second-pass-roundtrip',
    'human INDD: npm run e2e:indesign -- -- --indd <document.indd> --run-dir test/workspace/human-indd-e2e',
    '',
    'Default HTML: test/fixtures/e2e/architecture-report/deck.html',
    'Default unit mode: presentation',
    'Default target size: same as captured browser source pixels',
    'Default output: test/workspace/indesign-e2e-<timestamp>/',
  ].join('\n');
}

function parseReverseMode(value) {
  const mode = String(value || '').trim();
  if (['structured', 'inferred', 'observation'].includes(mode)) return mode;
  throw new Error(`Unsupported reverse mode: ${value}`);
}

async function runIndesignE2E(options = {}) {
  options = withResolvedReconstructionProfile(options);
  const context = createRunContext(options);
  fs.mkdirSync(context.runDir, { recursive: true });

  const compileSummary = await compileToInstructions(context, options);
  const health = runCli(['--json', '--pretty', 'server', 'health'], context.repoRoot);
  const healthJson = parseCliEnvelopeJson(health.stdout);
  if (!healthJson.ok || healthJson.tool_success === false) {
    throw new Error(`${resolveIndesignCliCommand()} health failed: ${health.stdout || health.stderr}`);
  }

  fs.writeFileSync(context.buildScriptPath, buildBuildJsx({
    repoRoot: context.repoRoot,
    instructionsPath: context.runInstructionsPath,
  }), 'utf8');

  const buildCli = runCli(['--json', '--pretty', 'script', 'run', context.buildScriptPath], context.repoRoot);
  const buildResult = parseCliResultJson(buildCli.stdout);
  assertCliResultOk(buildResult, 'InDesign build failed');
  try {
    assertNoTextOverset(buildResult);
    assertNoLossyVectorWarnings(buildResult);
  } catch (error) {
    closeOwnedBuildDocument(context, error);
    throw error;
  }

  let fidelity;
  try {
    fidelity = captureAndAuditForwardFidelity(context, options);
  } catch (error) {
    closeOwnedBuildDocument(context, error);
    throw error;
  }

  fs.writeFileSync(context.exportScriptPath, buildExportJsx({
    runDir: context.runDir,
    closeDocument: true,
    expectedMarker: 'html-indesign-indesign-e2e',
  }), 'utf8');

  const exportCli = runCli(['--json', '--pretty', 'script', 'run', context.exportScriptPath], context.repoRoot);
  const exportResult = parseCliResultJson(exportCli.stdout);
  assertCliResultOk(exportResult, 'InDesign export failed');
  assertPanelNameAuditOk(exportResult, {
    allowedPanelNames: observedPanelNamesForHtml(context.htmlPath),
  });

  const pdfPath = exportResult.outputs && exportResult.outputs.pdf;
  if (!pdfPath) throw new Error('InDesign export did not report a PDF path.');

  const verifyCli = runCli(['--json', '--pretty', 'export', 'verify', pdfPath], context.repoRoot);
  const verifyResult = parseCliEnvelopeJson(verifyCli.stdout);
  if (!verifyResult.ok || !verifyResult.data || verifyResult.data.signature_ok !== true) {
    throw new Error(`PDF verification failed: ${verifyCli.stdout}`);
  }

  const reverse = options.reverseRoundtrip
    ? await runReverseRoundtrip(context, options, fidelity)
    : null;

  const preview = options.skipPreview
    ? { skipped: true }
    : await renderPdfPreview(context, pdfPath);

  const result = {
    ok: aggregateE2EOk({ build: buildResult, fidelity, exportResult, reverse }),
    runDir: context.runDir,
    htmlPath: context.htmlPath,
    instructionsPath: context.runInstructionsPath,
    compile: compileSummary,
    build: buildResult,
    fidelity,
    export: exportResult,
    verify: verifyResult.data,
    reverse,
    preview,
  };
  fs.writeFileSync(context.resultPath, JSON.stringify(result, null, 2), 'utf8');
  if (!result.ok) {
    throw new Error(`E2E gate aggregation failed even though no individual assertion threw; see ${context.resultPath}`);
  }
  return result;
}

function aggregateE2EOk({ build, fidelity, exportResult, reverse }) {
  const checks = [
    Boolean(build) && build.ok !== false,
    Boolean(fidelity && fidelity.report && fidelity.report.ok === true),
    Boolean(exportResult) && exportResult.ok !== false,
  ];
  if (reverse) {
    checks.push(Boolean(reverse.author && reverse.author.audit && reverse.author.audit.ok === true));
    if (reverse.mode !== 'observation' && reverse.html && reverse.html.audit) {
      checks.push(reverse.html.audit.ok !== false);
    }
    if (reverse.canonicalStability) {
      checks.push(reverse.canonicalStability.ok === true);
    }
  }
  return checks.every(Boolean);
}

async function runHumanInddRoundtripE2E(options = {}) {
  options = withResolvedReconstructionProfile(options);
  const context = createHumanInddRunContext(options);
  fs.mkdirSync(context.runDir, { recursive: true });

  if (!fs.existsSync(context.inddPath)) {
    throw new Error(`INDD file not found: ${context.inddPath}`);
  }

  fs.writeFileSync(context.reverseScriptPath, buildReverseSnapshotJsx({
    repoRoot: context.repoRoot,
    outputPath: context.reverseSnapshotPath,
    inddPath: context.inddPath,
    closeDocument: true,
  }), 'utf8');

  const reverseCli = runCli(['--json', '--pretty', 'script', 'run', context.reverseScriptPath], context.repoRoot);
  const reverseSnapshot = parseCliResultJson(reverseCli.stdout);
  assertCliResultOk(reverseSnapshot, 'Human InDesign reverse snapshot failed');

  const { compileReverseSnapshotToHtml } = require('./indesign-reverse-export');
  const reverseHtml = compileReverseSnapshotToHtml({
    snapshotPath: context.reverseSnapshotPath,
    outDir: context.reverseOutDir,
    mode: options.reverseMode || 'observation',
    assetPolicy: options.assetPolicy || 'reference',
    reconstructionProfile: options.reconstructionProfile,
  });
  assertReverseCompilationOk(reverseHtml, 'Human InDesign reverse compilation failed');
  const author = reverseHtml.files && reverseHtml.files.author;
  if (!author || !author.audit || !author.audit.ok) {
    throw new Error(`Human InDesign reverse author package audit failed: ${JSON.stringify(author && author.audit || null, null, 2)}`);
  }

  const authorRoundtrip = await runIndesignE2E({
    repoRoot: context.repoRoot,
    workspaceDir: context.workspaceDir,
    runDir: context.authorRoundtripDir,
    htmlPath: author.entry,
    targetSize: options.targetSize,
    unitMode: options.unitMode,
    skipPreview: options.skipPreview,
    reverseRoundtrip: true,
    secondPassRoundtrip: true,
    reverseMode: options.reverseMode || 'observation',
    styleNameMap: options.styleNameMap,
    reconstructionProfile: options.reconstructionProfile,
  });

  const stability = authorRoundtrip.reverse && authorRoundtrip.reverse.canonicalStability;
  if (!stability || !stability.ok) {
    throw new Error(`Human InDesign author roundtrip is not byte-stable: ${JSON.stringify(stability || null, null, 2)}`);
  }

  const result = {
    ok: Boolean(author && author.audit && author.audit.ok === true)
      && authorRoundtrip.ok === true
      && stability.ok === true,
    runDir: context.runDir,
    inddPath: context.inddPath,
    reverseSnapshot,
    reverseHtml,
    author,
    authorRoundtrip,
    canonicalStability: stability,
    canonicalDrift: authorRoundtrip.reverse && authorRoundtrip.reverse.canonicalDrift || null,
  };
  fs.writeFileSync(context.resultPath, JSON.stringify(result, null, 2), 'utf8');
  return result;
}

async function compileToInstructions(context, options = {}) {
  const snapshot = await renderSnapshot({ htmlPath: context.htmlPath });
  const observedPanelNames = observedPanelNamesForHtml(context.htmlPath);
  const semanticPreset = loadSemanticPresetForHtml(context.htmlPath, options);
  const compiled = compileDocument(snapshot, {
    mode: 'editable-first',
    unitMode: options.unitMode || 'presentation',
    targetSize: options.targetSize || 'same',
    styleNameMap: loadStyleNameMapForHtml(context.htmlPath, options),
    preserveObservedLayerNames: observedPanelNames.length > 0,
  });
  const { model, instructions } = compiled;
  const validation = validateInstructions(instructions, {
    checkAssetFiles: true,
    baseDir: path.dirname(context.htmlPath),
  });
  if (!validation.valid) {
    const error = new Error('Compiled instructions failed validation.');
    error.validation = validation;
    throw error;
  }

  fs.mkdirSync(context.workspaceDir, { recursive: true });
  fs.mkdirSync(context.runDir, { recursive: true });
  const json = JSON.stringify(instructions, null, 2);
  fs.writeFileSync(context.defaultInstructionsPath, json, 'utf8');
  fs.writeFileSync(context.runInstructionsPath, json, 'utf8');
  fs.writeFileSync(context.expectedModelPath, JSON.stringify(model, null, 2), 'utf8');
  fs.writeFileSync(context.semanticPresetPath, JSON.stringify(semanticPreset, null, 2), 'utf8');

  const summary = {
    ok: true,
    htmlPath: context.htmlPath,
    pages: instructions.pages.length,
    unitMode: instructions.document.unitMode,
    coordinateUnit: instructions.document.coordinateUnit,
    targetSize: instructions.document.pages[0] ? {
      width: instructions.document.pages[0].width,
      height: instructions.document.pages[0].height,
    } : null,
    items: instructions.pages.reduce((sum, page) => sum + (page.items || []).length, 0),
    vectorPaths: instructions.pages.reduce((sum, page) => sum + (page.items || []).reduce(
      (itemSum, item) => itemSum + ((item.vectorGeometry && item.vectorGeometry.paths || []).length),
      0,
    ), 0),
    assets: (instructions.assets || []).length,
    fonts: Object.keys(instructions.styles.fonts || {}),
    styleCounts: {
      swatches: Object.keys(instructions.styles.swatches || {}).length,
      paragraphStyles: Object.keys(instructions.styles.paragraphStyles || {}).length,
      characterStyles: Object.keys(instructions.styles.characterStyles || {}).length,
      objectStyles: Object.keys(instructions.styles.objectStyles || {}).length,
      frameStyles: Object.keys(instructions.styles.frameStyles || {}).length,
      tableStyles: Object.keys(instructions.styles.tableStyles || {}).length,
    },
  };
  fs.writeFileSync(context.compileSummaryPath, JSON.stringify(summary, null, 2), 'utf8');
  return summary;
}

function parseTargetSize(value) {
  if (!value || value === 'same' || value === 'source') return null;
  const presets = {
    fhd: { width: 1920, height: 1080 },
    qhd: { width: 2560, height: 1440 },
    uhd: { width: 3840, height: 2160 },
    'dci-2k': { width: 2048, height: 1080 },
  };
  const key = String(value).toLowerCase();
  if (presets[key]) return { ...presets[key], name: key };
  const match = key.match(/^(\d+)x(\d+)$/);
  if (match) return { width: Number(match[1]), height: Number(match[2]), name: key };
  throw new Error(`Unsupported target size: ${value}`);
}

function architectureStyleNameMap() {
  const resolved = resolveSemanticPreset({ profile: 'architecture-report' });
  return presetToStyleNameMap(resolved.preset);
}

function loadStyleNameMapForHtml(htmlPath, options = {}) {
  if (options.styleNameMap) return options.styleNameMap;

  return presetToStyleNameMap(loadSemanticPresetForHtml(htmlPath, options));
}

function loadSemanticPresetForHtml(htmlPath, options = {}) {
  if (options.semanticPreset) return options.semanticPreset;

  const packageInfo = findAuthorPackageForHtml(htmlPath);
  if (packageInfo) {
    const resolved = resolveSemanticPreset({
      rootDir: packageInfo.rootDir,
      config: packageInfo.config,
    });
    return resolved.preset;
  }

  return resolveSemanticPreset({ profile: 'architecture-report' }).preset;
}

function findAuthorPackageForHtml(htmlPath) {
  const dir = path.dirname(path.resolve(htmlPath));
  const configPath = path.join(dir, 'deck.config.json');
  if (!fs.existsSync(configPath)) return null;
  return readAuthorPackage(configPath);
}

function resolveReverseSourceRootForHtml(htmlPath, options = {}) {
  if (options.sourceRoot) return path.resolve(options.sourceRoot);

  const packageInfo = findAuthorPackageForHtml(htmlPath);
  if (!packageInfo) return null;

  const resolvedHtmlPath = path.resolve(htmlPath);
  return path.resolve(packageInfo.entryPath) === resolvedHtmlPath
    ? packageInfo.rootDir
    : null;
}

function runCli(args, cwd) {
  return runCommand(resolveIndesignCliCommand(), args, cwd);
}

function closeOwnedBuildDocument(context, originalError) {
  const cleanupScriptPath = path.join(context.runDir, 'cleanup-after-gate-failure.jsx');
  try {
    fs.writeFileSync(cleanupScriptPath, hostJsx.buildCloseJsx({
      expectedMarker: 'html-indesign-indesign-e2e',
    }), 'utf8');
    const cleanupCli = runCli(['--json', '--pretty', 'script', 'run', cleanupScriptPath], context.repoRoot);
    const cleanupResult = parseCliResultJson(cleanupCli.stdout);
    if (!cleanupResult || cleanupResult.ok === false) originalError.cleanupFailure = cleanupResult;
  } catch (cleanupError) {
    originalError.cleanupFailure = {
      code: 'BUILD_DOCUMENT_CLOSE_FAILED',
      message: cleanupError.message,
    };
  }
}

function resolveIndesignCliCommand(env = process.env) {
  const explicit = env.INDESIGN_CLI_BIN;
  if (explicit && String(explicit).trim()) return String(explicit).trim();
  return 'indesign-cli';
}

function runCommand(command, args, cwd) {
  const result = spawnSync(command, args, {
    cwd,
    encoding: 'utf8',
    windowsHide: true,
  });
  if (result.error) throw result.error;
  if (result.status !== 0) {
    const message = [
      `${command} ${args.join(' ')} failed with exit code ${result.status}`,
      result.stdout,
      result.stderr,
    ].filter(Boolean).join('\n');
    throw new Error(message);
  }
  return result;
}

function parseCliResultJson(stdout) {
  const parsed = parseCliEnvelopeJson(stdout);
  if (parsed && parsed.data && parsed.data.result_json) return parsed.data.result_json;
  if (parsed && parsed.data && parsed.data.parsed && parsed.data.parsed.result) {
    return JSON.parse(parsed.data.parsed.result);
  }
  if (parsed && parsed.data && parsed.data.parsed && typeof parsed.data.parsed === 'object') {
    return parsed.data.parsed;
  }
  if (parsed && parsed.data) return parsed.data;
  return parsed;
}

function parseCliEnvelopeJson(stdout) {
  const parsed = typeof stdout === 'string' ? JSON.parse(stdout) : stdout;
  const childOutput = parsed && parsed.data && parsed.data.child && parsed.data.child.stdout_json;
  return childOutput ? parseCliEnvelopeJson(childOutput) : parsed;
}

function assertCliResultOk(result, message) {
  if (!result || result.ok === false || (Array.isArray(result.errors) && result.errors.length > 0)) {
    throw new Error(`${message}: ${JSON.stringify(result, null, 2)}`);
  }
}

function buildBuildJsx({ repoRoot, instructionsPath }) {
  return hostJsx.buildBuildJsx({ repoRoot, instructionsPath });
}

function buildExportJsx(options) {
  return hostJsx.buildExportJsx(options);
}

function buildReverseSnapshotJsx(options) {
  return hostJsx.buildReverseSnapshotJsx(options);
}

function captureAndAuditForwardFidelity(context, options = {}) {
  fs.writeFileSync(context.reverseScriptPath, buildReverseSnapshotJsx({
    repoRoot: context.repoRoot,
    outputPath: context.reverseSnapshotPath,
    closeDocument: false,
    expectedMarker: 'html-indesign-indesign-e2e',
    closeOnFailure: true,
  }), 'utf8');

  const reverseCli = runCli(['--json', '--pretty', 'script', 'run', context.reverseScriptPath], context.repoRoot);
  const snapshotResult = parseCliResultJson(reverseCli.stdout);
  assertCliResultOk(snapshotResult, 'InDesign fidelity snapshot failed');

  const expectedModel = readJsonFile(context.expectedModelPath);
  const semanticPreset = readJsonFile(context.semanticPresetPath);
  const instructions = readJsonFile(context.runInstructionsPath);
  const actualSnapshot = readJsonFile(context.reverseSnapshotPath);
  const actualModel = reverseSnapshotToSemanticModel(actualSnapshot, {
    mode: 'structured',
    semanticPreset,
  });
  const report = auditForwardFidelity({
    expectedModel,
    instructions,
    actualSnapshot,
    actualModel,
  });
  fs.writeFileSync(context.fidelityReportPath, JSON.stringify(report, null, 2), 'utf8');
  if (!report.ok) {
    const first = report.errors[0] || {};
    const error = new Error(
      `InDesign fidelity gate failed at ${first.pageId || 'document'} / ${first.itemId || first.field || 'unknown'}: ${first.code || 'FORWARD_FIDELITY_CHANGED'}. See ${context.fidelityReportPath}`,
    );
    error.code = 'FORWARD_FIDELITY_GATE_FAILED';
    error.report = report;
    throw error;
  }
  return { snapshot: snapshotResult, report };
}

function readJsonFile(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

async function runReverseRoundtrip(context, options = {}, fidelity = null) {
  const reverseMode = options.reverseMode || 'structured';
  if (!fidelity || !fidelity.snapshot || !fidelity.report || fidelity.report.ok !== true) {
    throw new Error('InDesign reverse roundtrip requires a successful forward fidelity snapshot.');
  }
  const reverseResult = fidelity.snapshot;

  const { compileReverseSnapshotToHtml } = require('./indesign-reverse-export');
  const sourceRoot = resolveReverseSourceRootForHtml(context.htmlPath, options);
  const reverseCompileOptions = {
    snapshotPath: context.reverseSnapshotPath,
    outDir: context.reverseOutDir,
    mode: reverseMode,
    reconstructionProfile: options.reconstructionProfile,
  };
  if (sourceRoot) {
    reverseCompileOptions.sourceRoot = sourceRoot;
  }
  const htmlResult = compileReverseSnapshotToHtml(reverseCompileOptions);
  assertReverseCompilationOk(htmlResult, 'InDesign reverse compilation failed');
  const reverseHtmlPath = path.join(context.reverseOutDir, 'deck.html');
  const reverseHtml = fs.readFileSync(reverseHtmlPath, 'utf8');
  const htmlAudit = reverseMode === 'observation'
    ? auditReverseHtmlSemantics(reverseHtml)
    : assertReverseHtmlSemantics(reverseHtml, reverseHtmlPath);
  const authorAudit = htmlResult.files && htmlResult.files.author && htmlResult.files.author.audit;
  if (!authorAudit || !authorAudit.ok) {
    throw new Error(`Reverse author package audit failed: ${JSON.stringify(authorAudit, null, 2)}`);
  }
  const author = Object.assign({}, htmlResult.files.author, { audit: authorAudit });
  let secondPass = null;
  let canonicalDrift = null;
  let canonicalStability = null;
  if (options.secondPassRoundtrip) {
    secondPass = await runIndesignE2E({
      repoRoot: context.repoRoot,
      workspaceDir: context.workspaceDir,
      runDir: path.join(context.runDir, 'second-pass'),
      htmlPath: htmlResult.files.author.entry,
      targetSize: options.targetSize,
      unitMode: options.unitMode,
      skipPreview: true,
      reverseRoundtrip: true,
      secondPassRoundtrip: false,
      reverseMode,
      styleNameMap: options.styleNameMap,
      reconstructionProfile: options.reconstructionProfile,
    })
    const reportDir = path.join(htmlResult.files.author.outDir, 'reports');
    canonicalStability = auditSecondPassAuthorStability({
      sourceRoot: htmlResult.files.author.outDir,
      reverseRoot: secondPass.reverse && secondPass.reverse.author && secondPass.reverse.author.outDir,
      reportDir,
    });
    canonicalDrift = canonicalStability.sourceDrift;
    if (!canonicalStability.ok) {
      throw new Error(`Second-pass reverse author package is not byte-stable or lost content/structure: ${JSON.stringify(canonicalStability, null, 2)}`);
    }
  }

  return {
    mode: reverseMode,
    snapshot: reverseResult,
    fidelity: fidelity.report,
    html: {
      ...htmlResult,
      audit: htmlAudit,
    },
    author,
    secondPass,
    canonicalDrift,
    canonicalStability,
  };
}

async function renderPdfPreview(context, pdfPath) {
  fs.mkdirSync(context.previewDir, { recursive: true });
  const prefix = path.join(context.previewDir, 'page');
  const render = spawnSync('pdftoppm', ['-png', '-r', '96', pdfPath, prefix], {
    cwd: context.repoRoot,
    encoding: 'utf8',
    windowsHide: true,
  });
  if (render.error || render.status !== 0) {
    return {
      ok: false,
      warning: 'pdftoppm failed; PDF was exported but PNG preview was not generated.',
      stderr: render.stderr || String(render.error || ''),
    };
  }

  const pages = fs.readdirSync(context.previewDir)
    .filter((name) => /^page-\d+\.png$/i.test(name))
    .sort((a, b) => pageNumber(a) - pageNumber(b));
  const htmlPath = path.join(context.previewDir, 'contact-sheet.html');
  const pngPath = path.join(context.runDir, 'architecture-report-indesign-contact-sheet.png');
  fs.writeFileSync(htmlPath, contactSheetHtml(pages), 'utf8');

  try {
    const browser = await launchEdgeBrowser();
    const page = await browser.newPage({ viewport: { width: 1400, height: 1800 }, deviceScaleFactor: 1 });
    await page.goto(pathToFileURL(htmlPath).href);
    await page.screenshot({ path: pngPath, fullPage: true });
    await browser.close();
  } catch (error) {
    if (error && error.code === EDGE_NOT_AVAILABLE) throw error;
    return {
      ok: false,
      pages: pages.map((name) => path.join(context.previewDir, name)),
      html: htmlPath,
      warning: `Playwright contact sheet screenshot failed: ${String(error)}`,
    };
  }

  return {
    ok: true,
    pages: pages.map((name) => path.join(context.previewDir, name)),
    html: htmlPath,
    image: pngPath,
  };
}

function contactSheetHtml(pages) {
  const images = pages.map((name, index) => (
    `<figure><figcaption>Page ${index + 1}</figcaption><img src="./${escapeHtml(name)}" alt="Page ${index + 1}"></figure>`
  )).join('\n');
  return `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>InDesign E2E Contact Sheet</title>
  <style>
    body { margin: 24px; background: #eeeeee; font: 13px Arial, sans-serif; color: #222222; }
    main { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; }
    figure { margin: 0; padding: 10px; background: #ffffff; border: 1px solid #bcbcbc; }
    figcaption { margin: 0 0 8px; }
    img { display: block; width: 100%; height: auto; }
  </style>
</head>
<body>
  <main>
${images}
  </main>
</body>
</html>
`;
}

function pageNumber(name) {
  const match = String(name).match(/page-(\d+)/i);
  return match ? Number(match[1]) : 0;
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function assertReverseCompilationOk(result, message) {
  if (result && result.ok === true) return;
  const evidence = result && result.report ? result.report : result || null;
  throw new Error(`${message}: ${JSON.stringify(evidence, null, 2)}`);
}

function withResolvedReconstructionProfile(options) {
  const reconstructionProfile = options && options.reconstructionProfile
    ? assertResolvedReconstructionProfile(options.reconstructionProfile)
    : resolveReconstructionProfile({});
  return { ...(options || {}), reconstructionProfile };
}

function parseAlgorithmList(value) {
  return String(value || '')
    .split(/[\s,]+/)
    .map((entry) => entry.trim())
    .filter(Boolean);
}

async function main() {
  const repoRoot = path.resolve(__dirname, '..');
  const options = parseArgs(process.argv.slice(2), repoRoot);
  if (options.help) {
    console.log(usage());
    return;
  }
  if (options.inddPath) {
    const result = await runHumanInddRoundtripE2E(options);
    console.log(JSON.stringify({
      ok: result.ok,
      runDir: result.runDir,
      inddPath: result.inddPath,
      pages: result.reverseHtml.report && result.reverseHtml.report.pages,
      items: result.reverseHtml.report && result.reverseHtml.report.items,
      assets: result.reverseHtml.report && result.reverseHtml.report.assets,
      authorEntry: result.author && result.author.entry,
      roundtripRunDir: result.authorRoundtrip && result.authorRoundtrip.runDir,
      canonicalDrift: result.canonicalDrift && result.canonicalDrift.stats,
    }, null, 2));
    return;
  }
  const result = await runIndesignE2E(options);
  console.log(JSON.stringify({
    ok: result.ok,
    runDir: result.runDir,
    pages: result.compile.pages,
    unitMode: result.compile.unitMode,
    coordinateUnit: result.compile.coordinateUnit,
    targetSize: result.compile.targetSize,
    items: result.compile.items,
    assets: result.compile.assets,
    counts: result.export.counts,
    outputs: result.export.outputs,
    preview: result.preview,
  }, null, 2));
}

if (require.main === module) {
  main().catch((error) => {
    if (error.validation) console.error(JSON.stringify(error.validation, null, 2));
    else console.error(error && error.stack ? error.stack : String(error));
    process.exit(1);
  });
}

module.exports = {
  createRunContext,
  createHumanInddRunContext,
  buildBuildJsx,
  buildExportJsx,
  buildReverseSnapshotJsx,
  architectureStyleNameMap,
  loadStyleNameMapForHtml,
  parseCliEnvelopeJson,
  parseCliResultJson,
  resolveIndesignCliCommand,
  parseArgs,
  parseTargetSize,
  runIndesignE2E,
  runHumanInddRoundtripE2E,
  resolveReverseSourceRootForHtml,
  assertReverseCompilationOk,
};
