const TEXT_STYLE_FIELDS = Object.freeze([
  'fontFamily',
  'fontStyle',
  'fontWeight',
  'pointSize',
  'leading',
  'tracking',
  'justification',
  'align',
  'firstLineIndent',
  'leftIndent',
  'rightIndent',
  'spaceBefore',
  'spaceAfter',
]);

const TEXT_OVERRIDE_FIELDS = Object.freeze([
  'fillColor',
]);

const LINE_STYLE_FIELDS = Object.freeze([
  'lineEndMarker',
  'lineStartMarker',
  'strokeColor',
  'strokeStyle',
  'strokeWeight',
]);

const OBJECT_STYLE_FIELDS = Object.freeze([
  'blendMode',
  'cornerRadius',
  'fillColor',
  'fillOpacity',
  'opacity',
  'strokeAlignment',
  'strokeColor',
  'strokeLineCap',
  'strokeLineJoin',
  'strokeMiterLimit',
  'strokeOpacity',
  'strokeStyle',
  'strokeTint',
  'strokeWeight',
]);

const ASSET_PLACEMENT_FIELDS = Object.freeze([
  'pageNumber',
  'crop',
  'transparentBackground',
  'visibleLayers',
  'hiddenLayers',
  'layers',
  'contentBounds',
  'contentScale',
  'contentOffset',
  'fit',
]);

function styleAtomForItem(item) {
  if (!isPlainObject(item)) {
    return null;
  }
  if (isLineItem(item)) {
    return lineStyleAtom(item);
  }
  if (isTextItem(item)) {
    return textStyleAtom(item);
  }
  if (isAssetItem(item)) {
    return assetStyleAtom(item);
  }
  if (isObjectItem(item)) {
    return objectStyleAtom(item);
  }
  return null;
}

function textStyleAtom(item) {
  const textStyle = isPlainObject(item.textStyle) ? item.textStyle : {};
  const properties = pickDefined(textStyle, TEXT_STYLE_FIELDS);
  const overrideCandidates = pickDefined(textStyle, TEXT_OVERRIDE_FIELDS);
  return {
    kind: 'text',
    properties,
    overrideCandidates,
  };
}

function lineStyleAtom(item) {
  const visualStyle = isPlainObject(item.visualStyle) ? item.visualStyle : {};
  return {
    kind: 'line',
    properties: pickPresent(visualStyle, LINE_STYLE_FIELDS),
    overrideCandidates: {},
  };
}

function objectStyleAtom(item) {
  const visualStyle = isPlainObject(item.visualStyle) ? item.visualStyle : {};
  return {
    kind: 'object',
    properties: pickDefined(visualStyle, OBJECT_STYLE_FIELDS),
    overrideCandidates: {},
  };
}

function assetStyleAtom(item) {
  const asset = isPlainObject(item.asset) ? item.asset : {};
  const placement = isPlainObject(asset.placement) ? asset.placement : {};
  return {
    kind: 'asset',
    properties: pickDefined(placement, ASSET_PLACEMENT_FIELDS),
    overrideCandidates: {},
  };
}

function isTextItem(item) {
  return item.role === 'text';
}

function isLineItem(item) {
  return item.role === 'line';
}

function isAssetItem(item) {
  return item.role === 'graphic' && isPlainObject(item.asset) && isPlainObject(item.asset.placement);
}

function isObjectItem(item) {
  return item.role === 'shape' && isPlainObject(item.visualStyle);
}

function pickDefined(source, keys) {
  const result = {};
  for (const key of keys) {
    const value = source[key];
    if (typeof value !== 'undefined' && value !== null) {
      result[key] = value;
    }
  }
  return sortObject(result);
}

function pickPresent(source, keys) {
  const result = {};
  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(source, key)) {
      result[key] = source[key];
    }
  }
  return sortObject(result);
}

function sortObject(value) {
  if (Array.isArray(value)) {
    return value.map((item) => sortObject(item));
  }
  if (!isPlainObject(value)) {
    return value;
  }
  const sorted = {};
  for (const key of Object.keys(value).sort()) {
    sorted[key] = sortObject(value[key]);
  }
  return sorted;
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

module.exports = Object.freeze({
  styleAtomForItem,
  sortObject,
});
